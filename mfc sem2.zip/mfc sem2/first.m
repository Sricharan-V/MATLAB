clc
clear
A=[1 2 3;4 5 6;5 7 9];
det(A)
