f=heaviside(t);
f_FT=fourier(f)
fplot(f)