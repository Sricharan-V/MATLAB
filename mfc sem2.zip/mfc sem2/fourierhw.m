%write a matlab code to find the fourier transforms of the functions
%f(t)=a*cos(bt)
%f(t)=a*sin(bt)