clc
clear
syms t
a = 1;
b = 2;
f = rectangularPulse(a,b,t);
f_FT = fourier(f)
fplot(f_FT)