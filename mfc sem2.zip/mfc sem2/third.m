clc
clear
A=input('Enter a square matrix')
det(A)
null(A)
if(det(A)==0)
    disp('Not a Unique Solution')
else
    disp('Unique Solution')
end
