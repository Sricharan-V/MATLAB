clc
clear
A=[2,4,-6;1,5,3;1,3,2];
N = length(A);
U = zeros(N,N);
L = zeros(N,N);
for a=1:N
    L(a,a)=1;
end
U(1,:) = A(1,:);
L(:,1) = A(:,1)/U(1,1);
for i = 2:N
    for j = i:N
        U(i,j)=A(i,j)-L(i,1:i-1)*U(1:i-1,j);
    end
    for k = i+1:N
        L(k,i)=(A(k,i)-L(k,1:i-1)*U(1:i-1,i))/U(i,i);
    end
end

L
U
L*U